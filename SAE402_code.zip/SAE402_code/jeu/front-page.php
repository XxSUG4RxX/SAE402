<?php 
    get_header();
?>


<style>

header {
  background-image: url("<?php the_field("header_background"); ?>");
}

.monde {
  background-image: url("<?php the_field("monde_background"); ?>");
}

.soundtrack {
  background-image: url("<?php the_field("soundtrack_background"); ?>");
}


</style> 


<main>

<div class="monde" id="link1">

<h1 class="monde__title title stroke-blue">Arcadia</h1>

<div class="monde__content">

  <img class="monde__pic" src="<?php the_field("monde_img"); ?>">
  <p class="monde__txt">Welcome to the enchanting realm of Arcadia, a land where magic and mystery intertwine. <br>
     Within its borders, majestic dragons soar through cerulean skies, powerful wizards weave spells of wonder, and noble princes embark on epic quests. At the helm of this wondrous kingdom sits King Auriculus, a wise and benevolent ruler whose guidance ensures the prosperity of his realm. Explore every corner of this captivating land, where adventure awaits at every turn and tales of heroism are born anew.
  </p>
</div>
  
</div>



<!-- ------------------------- PERSONNAGES -->

    <div class="personnages" id="link2">

<div class="personnages__title_content">
  <h1 class="title">Personnages</h1>
</div>




      <article class="personnages__content">


        <div class="personnages__info">

          <div class="personnages__txt">
            <h1 class="personnages__name"><?php the_field("perso1"); ?></h1>
            <p><?php the_field("perso1_desc"); ?></p>
            <img class="personnages__pic" src="<?php the_field("perso1_pic"); ?>">
          </div>

          <div class="personnages__one">
            <h1 class="personnages__name"><?php the_field("perso1"); ?></h1>
            <img src="<?php the_field("perso1_pic_sprite"); ?>">
          </div>

        </div>





        <div class="personnages__info">

        <div class="personnages__txt">
            <h1 class="personnages__name"><?php the_field("perso2"); ?></h1>
            <p><?php the_field("perso2_desc"); ?></p>
            <img class="personnages__pic" src="<?php the_field("perso2_pic"); ?>">
          </div>

          <div class="personnages__one">
            <h1 class="personnages__name"><?php the_field("perso2"); ?></h1>
            <img src="<?php the_field("perso2_pic_sprite"); ?>">
          </div>

        </div>





        <div class="personnages__info">

        <div class="personnages__txt">
            <h1 class="personnages__name"><?php the_field("perso3"); ?></h1>
            <p><?php the_field("perso3_desc"); ?></p>
            <img class="personnages__pic" src="<?php the_field("perso3_pic"); ?>">
          </div>

          <div class="personnages__one">
            <h1 class="personnages__name"><?php the_field("perso3"); ?></h1>
            <img src="<?php the_field("perso3_pic_sprite"); ?>">
          </div>
        </div>

      </article>

    </div>
  </div>



  <!-- -----------------------------UPDATES  -->

  <div class="updates" id="link3">

    <img src="<?php the_field("maj_actuelle"); ?>">

  </div>

  <!-- -----------------------------------SOUNDTRACK -->
  <div class="soundtrack" id="link4">


    <h1 class="title"> Soundtrack</h1>
    
    <p>Listen to our tracks!</p>


    <iframe width="30%" height="300" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/1633319337&color=%23ffcf52&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true"></iframe><div style="font-size: 10px; color: #cccccc;line-break: anywhere;word-break: normal;overflow: hidden;white-space: nowrap;text-overflow: ellipsis; font-family: Interstate,Lucida Grande,Lucida Sans Unicode,Lucida Sans,Garuda,Verdana,Tahoma,sans-serif;font-weight: 100;"><a href="https://soundcloud.com/mof-e" title="mofe." target="_blank" style="color: #cccccc; text-decoration: none;"></a> · <a href="https://soundcloud.com/mof-e/prince-of-egypt" title="Knightress OST" target="_blank" style="color: #cccccc; text-decoration: none;">Knightress OST</a></div>

  </div>



</main>

<?php get_footer(); ?>