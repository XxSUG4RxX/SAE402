<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>



<body>
<header>
<div class="menu">
        <ul>
          <li><a href="#link1"><?php the_field("link1"); ?></a></li>
          <li><a href="#link2"><?php the_field("link2"); ?></a></li>
          <li><a href="#link3"><?php the_field("link3"); ?></a></li>
          <li><a href="#link4"><?php the_field("link4"); ?></a></li>
          <li><a href="https://www.a-braybrooke.mmi-limoges.fr/jeuSAE402/index.html"><?php the_field("jouer"); ?></a></li>
        </ul>
    
      </div>
      
      <div class="header__content">

        <img class="header__logo" src="<?php the_field("header_logo"); ?>">
        <p class="header__subtxt">Suivez Knightress et sauvez le ... <span class="highlight stroke-black">dragon</span>?</p>
  
        <div class="jeu__content">
          <img src="<?php the_field("header_screen"); ?>";>
        </div>
      </div>
</div>
</header>

    