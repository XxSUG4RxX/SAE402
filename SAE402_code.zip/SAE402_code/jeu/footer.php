<footer>
    <div class="footer__content">

      <!-- <img class="footer__pic" src="./assets/footer_pic.png"> -->
      <div class="footer__socials">
        <img src="<?php the_field("rating"); ?>">
      </div>
      <p>© 2024 Knightress. All rights reserved.</p>
      <p>Aysha Braybrooke | Romain Plouseau | Franck Puybonnieux</p>
    </div>
  </footer>

</body>
</html>