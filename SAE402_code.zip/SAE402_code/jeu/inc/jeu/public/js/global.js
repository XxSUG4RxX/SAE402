document.addEventListener('DOMContentLoaded', (event) => {
    console.log('here in js');
});