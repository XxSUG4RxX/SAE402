<?php

show_admin_bar(true);
add_theme_support( 'post-thumbnails' );

/** STYLES */
/**
 * Enqueue scripts and styles.
 */
function init_scripts() {
    // style css
	wp_enqueue_style( 'flowbite', 'https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.css', array());
	wp_enqueue_style('global-style', get_template_directory_uri().'/public/css/global.css', [], null, 'all');

    // lib js
	wp_enqueue_script( 'tailwind', 'https://cdn.tailwindcss.com', array());
	wp_enqueue_script( 'custom-script', get_template_directory_uri().'/public/js/global.js');
	wp_enqueue_script( 'flowbite', 'https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.js', array(), null, false);
}
add_action( 'wp_enqueue_scripts', 'init_scripts' );


/** ACF */
function acf_json_save_groups($path) {
	return get_stylesheet_directory() . '/inc';
}
add_filter( 'acf/settings/save_json', 'acf_json_save_groups' );

function acf_json_load_point($paths) {
	unset($paths[0]);
	$paths[] = get_stylesheet_directory() . '/inc';
	return $paths;
}
add_filter('acf/settings/load_json', 'acf_json_load_point');


/** MENUS */
function register_custom_menus() {
    register_nav_menus(
      array(
        'header-primary-menu' => __('Menu principal header'),
        'footer-menu' => __('Menu footer'),
        'header-secondary-menu' => __('Menu secondaire header'),
      )
    );
}
add_action('init', 'register_custom_menus');

