<?php 
    get_header();
    the_post();
?>

