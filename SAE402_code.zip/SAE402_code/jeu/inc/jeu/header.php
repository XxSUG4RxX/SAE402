<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body>
<header class="menu">

        <ul>
          <li><a href="#Soundtrack"><?php the_field("link_1");?></a></li>
          <li><a href="#">Personnages</a></li>
          <li><a href="#">Contact</a></li>
          <li class="menu__play"><a href="#">Jouer</a></li>
        </ul>
    
</header>

    